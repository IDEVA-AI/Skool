import { Home, BookOpen, Star, Settings, LogOut, LayoutGrid, Lock, Users } from "lucide-react";

export const currentUser = {
  name: "Júlio Carvalho",
  avatar: "https://github.com/shadcn.png",
  isPremium: false,
};

export const communities = [
  { id: "backroom", name: "BACKROOM", icon: "💀" },
  { id: "zona", name: "ZONA COMMUNITY", icon: "zona" },
  { id: "ai", name: "AI Automation (A-Z)", icon: "🤖" },
];

export const courses = [
  {
    id: 1,
    communityId: "zona",
    title: "PROMPT$",
    description: "Acesse os bastidores do meu negócio de R$ 400.000 por mês em tempo real",
    progress: 0,
    totalModules: 12,
    completedModules: 0,
    cover: "black", 
    locked: false,
    imageText: "PROMPT$",
  },
  {
    id: 2,
    communityId: "zona",
    title: "[UPGRADE] ⚡ CLAREZA BRUTAL",
    description: "Aprenda a comunicar com clareza, eliminar objeções e conquistar clientes com...",
    progress: 0,
    totalModules: 8,
    completedModules: 0,
    cover: "black",
    locked: false,
    imageText: "CLAREZA BRUTAL",
  },
  {
    id: 3,
    communityId: "zona",
    title: "[RESTRITO] ⚡ AgenteGPT (ativos...",
    description: "Meu agenteGPT que transformar ideias soltas em ativos de pré-venda de R$ 100 a...",
    progress: 0,
    totalModules: 15,
    completedModules: 0,
    cover: "black",
    locked: true,
    imageText: "Private Course",
  },
   {
    id: 4,
    communityId: "zona",
    title: "Q&A ZONA",
    description: "Gravações das sessões de mentoria mensal",
    progress: 0,
    totalModules: 5,
    completedModules: 0,
    cover: "black",
    locked: false,
    imageText: "Q&A ZONA",
  },
  {
    id: 5,
    communityId: "backroom",
    title: "DOUG.EXE 7.0",
    description: "A nova implementação completa.",
    progress: 45,
    totalModules: 20,
    completedModules: 9,
    cover: "black",
    locked: false,
    imageText: "DOUG.EXE",
  },
];

export const posts = [
  {
    id: 1,
    author: "-Doug Demarco",
    role: "AVISOS DOUG",
    avatar: "https://i.pravatar.cc/150?u=doug",
    title: "NOVA BACKROOM: DOUG.EXE 7.0 + ATUALIZAÇÕES",
    content: "Pessoal, publiquei agora um conteúdo completo explicando toda a nova estrutura da Backroom, incluindo: - Doug.exe 7.0 - Nova Implementação - Novo Promptbook - Estrutura de Chats Fixos -",
    timestamp: "3d",
    likes: 10,
    comments: 8,
    pinned: true,
    likedBy: [
        "https://i.pravatar.cc/150?u=1",
        "https://i.pravatar.cc/150?u=2",
        "https://i.pravatar.cc/150?u=3",
        "https://i.pravatar.cc/150?u=4"
    ],
    lastComment: "New comment 2d ago",
    attachment: {
        title: "BÔNUS DESBLOQUEÁVEL: RAYA",
        description: "Uma agente IA perigosa criada pelo próprio DOUG.EXE 3.0. Fria, elegante, brutal.",
        image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=200&auto=format&fit=crop",
        progress: 0,
        locked: true
    },
    commentsList: [
        {
            id: 101,
            author: "Breno Carvalho",
            avatar: "https://i.pravatar.cc/150?u=breno",
            content: "Opa @-Doug Demarco não estou conseguindo acessar, aparece bloqueado pode me ajudar?",
            timestamp: "Oct 2",
            likes: 1,
            replies: [
                {
                    id: 102,
                    author: "Bruno Nogueira",
                    avatar: "https://i.pravatar.cc/150?u=bruno",
                    content: "@Breno Carvalho Irmão, doug falou sobre isso em um outro post:\n\n⚠️ AVISO PARA TODOS\nAlguns conteúdos foram movidos para privado. Se você tinha acesso e agora não tem mais, verifique o e-mail da Skool.\nProcure por algo como: \"-Doug Demarco invited you to join 💀 BACKROOM\", e-mail enviado por: -Doug Demarco <noreply@skool.com>\n(procure em promoções/spam)\nEsse e-mail foi enviado há 10-15 dias",
                    timestamp: "Oct 2",
                    likes: 0
                }
            ]
        }
    ]
  },
  {
    id: 2,
    author: "Marcus Chen",
    role: "Aluno",
    avatar: "https://i.pravatar.cc/150?u=marcus",
    title: "Reflexão sobre o Módulo 3",
    content: "Acabei de terminar o módulo 3 de 'Fundamentos do Minimalismo'. O conceito de 'espaço negativo' na produtividade é um divisor de águas. Alguém já aplicou isso na agenda diária?",
    timestamp: "4h",
    likes: 8,
    comments: 3,
    pinned: false,
    likedBy: [
        "https://i.pravatar.cc/150?u=5",
        "https://i.pravatar.cc/150?u=6"
    ],
    lastComment: "New comment 1h ago",
    commentsList: [
        {
            id: 201,
            author: "Doug Demarco",
            avatar: "https://i.pravatar.cc/150?u=doug",
            role: "AVISOS DOUG",
            content: "Exatamente! O espaço negativo é onde a criatividade respira. Continue assim, Marcus!",
            timestamp: "2h ago",
            likes: 4
        }
    ]
  },
  {
    id: 3,
    author: "Elena Rodriguez",
    role: "Aluno",
    avatar: "https://i.pravatar.cc/150?u=elena",
    title: "Dúvida Masterclass Premium",
    content: "Pergunta sobre a masterclass premium: Ela cobre dinâmicas de gestão de equipe? Estou pensando em fazer o upgrade.",
    timestamp: "1d",
    likes: 5,
    comments: 2,
    pinned: false,
    likedBy: [
        "https://i.pravatar.cc/150?u=7"
    ],
    lastComment: "New comment 5h ago",
    commentsList: [
        {
            id: 301,
            author: "Sarah Jones",
            avatar: "https://i.pravatar.cc/150?u=sarah",
            content: "Essa masterclass é incrível! Fiz mês passado e mudou completamente minha forma de liderar.",
            timestamp: "5h ago",
            likes: 2
        }
    ]
  },
];

export const navigation = [
  { name: "Comunidade", href: "/", icon: Users },
  { name: "Classroom", href: "/courses", icon: LayoutGrid },
];

export const chats = [
  {
    id: 1,
    user: "Derrick Lions",
    avatar: "https://i.pravatar.cc/150?u=derrick",
    message: "Hello Júlio How're you doing? How's your journey goin...",
    timestamp: "Oct 21",
    unread: true,
    count: 1
  },
  {
    id: 2,
    user: "-Doug Demarco",
    avatar: "https://i.pravatar.cc/150?u=doug",
    message: "O Storyads também está bloqueado.",
    timestamp: "Aug 18",
    unread: false
  },
  {
    id: 3,
    user: "Albert Shiney",
    avatar: "https://i.pravatar.cc/150?u=albert",
    message: "Yeah so we just launched the professional widget... Yo...",
    timestamp: "Aug 10",
    unread: true,
    count: 1
  },
  {
    id: 4,
    user: "Elspeth Desrosiers",
    avatar: "https://i.pravatar.cc/150?u=elspeth",
    message: "Hey! I'm good, how are you?",
    timestamp: "Jul 29",
    unread: false
  },
  {
    id: 5,
    user: "MacPhason Scott",
    avatar: "https://i.pravatar.cc/150?u=mac",
    message: "Hi Julio, how are you doing today? What have you learn...",
    timestamp: "Jun 16",
    unread: false
  },
  {
    id: 6,
    user: "Oaklynn Peyton",
    avatar: "https://i.pravatar.cc/150?u=oak",
    message: "Hello 👋 bro",
    timestamp: "Jun 9",
    unread: false
  }
];

export const notifications = [
  {
    id: 1,
    user: "Albert Shiney",
    avatar: "https://i.pravatar.cc/150?u=albert",
    action: "nova postagem",
    context: "(admin)",
    content: "Get access to an AI version of us (Waitlist closing)",
    timestamp: "14h",
    unread: true,
    icon: "👑"
  },
  {
    id: 2,
    user: "Albert Shiney",
    avatar: "https://i.pravatar.cc/150?u=albert",
    action: "nova postagem",
    context: "(seguindo)",
    content: "Get First AI client in 10 mins!",
    timestamp: "14h",
    unread: true,
    icon: "👑"
  },
  {
    id: 3,
    user: "Albert Shiney",
    avatar: "https://i.pravatar.cc/150?u=albert",
    action: "nova postagem",
    context: "(seguindo)",
    content: "The 1% QA Call Happening now (For Premium)",
    timestamp: "21h",
    unread: true,
    icon: "👑"
  },
  {
    id: 4,
    user: "Albert Shiney",
    avatar: "https://i.pravatar.cc/150?u=albert",
    action: "nova postagem",
    context: "(seguindo)",
    content: "I built this AI Agent in 1 hour (and got paid $1200)",
    timestamp: "2d",
    unread: true,
    icon: "👑"
  },
  {
    id: 5,
    user: "-Doug Demarco",
    avatar: "https://i.pravatar.cc/150?u=doug",
    action: "nova postagem",
    context: "(admin)",
    content: "NOVA BACKROOM: DOUG.EXE 7.0 + ATUALIZAÇÕES",
    timestamp: "3d",
    unread: true,
    isImportant: true
  },
  {
    id: 6,
    user: "Albert Shiney",
    avatar: "https://i.pravatar.cc/150?u=albert",
    action: "nova postagem",
    context: "(admin)",
    content: "The ONE thing that took us from $5k/mo to $150k/...",
    timestamp: "4d",
    unread: true,
    icon: "👑"
  },
  {
    id: 7,
    user: "Albert Shiney",
    avatar: "https://i.pravatar.cc/150?u=albert",
    action: "nova postagem",
    context: "(seguindo)",
    content: "Make $1M with AI in 2026 (Start Here)",
    timestamp: "6d",
    unread: true,
    icon: "👑"
  }
];
