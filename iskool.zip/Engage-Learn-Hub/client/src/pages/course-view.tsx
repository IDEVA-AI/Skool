import { useParams } from "wouter";
import { courses } from "@/lib/data";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { CheckCircle2, Play, PlayCircle, FileText, Download, ChevronLeft } from "lucide-react";
import { Link } from "wouter";
import { cn } from "@/lib/utils";

export default function CourseView() {
  const params = useParams();
  const courseId = parseInt(params.id || "1");
  const course = courses.find(c => c.id === courseId) || courses[0];

  // Mock modules data
  const modules = Array.from({ length: course.totalModules }, (_, i) => ({
    id: i + 1,
    title: `Módulo ${i + 1}: ${i === 0 ? "Introdução e Visão Geral" : i === 1 ? "Conceitos Fundamentais" : "Aplicação Avançada"}`,
    duration: "15:00",
    completed: i < course.completedModules,
    current: i === course.completedModules,
  }));

  return (
    <div className="flex flex-col h-[calc(100vh-6rem)] -m-4 md:-m-8">
      {/* Top Bar */}
      <div className="h-14 border-b border-border/40 bg-background flex items-center px-4 md:px-8 shrink-0 gap-4">
        <Link href="/courses">
          <Button variant="ghost" size="sm" className="gap-2">
            <ChevronLeft className="h-4 w-4" />
            Voltar
          </Button>
        </Link>
        <Separator orientation="vertical" className="h-6" />
        <h1 className="font-heading font-semibold text-sm md:text-base truncate flex-1">
          {course.title}
        </h1>
        <div className="text-xs text-muted-foreground hidden md:block">
          {course.progress}% Concluído
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar Modules List - Moved to Left */}
        <div className="w-80 border-r border-border/40 bg-background hidden lg:flex flex-col">
          <div className="p-4 border-b border-border/40">
            <h3 className="font-semibold">Conteúdo do Curso</h3>
          </div>
          <ScrollArea className="flex-1">
            <div className="p-4 space-y-1">
              {modules.map((module) => (
                <div 
                  key={module.id}
                  className={cn(
                    "flex items-start gap-3 p-3 rounded-md text-sm transition-colors cursor-pointer",
                    module.current 
                      ? "bg-primary/5 text-primary font-medium border border-primary/10" 
                      : "hover:bg-muted/50 text-muted-foreground"
                  )}
                >
                  <div className="mt-0.5">
                    {module.completed ? (
                      <CheckCircle2 className="h-4 w-4 text-accent" />
                    ) : module.current ? (
                      <PlayCircle className="h-4 w-4 text-primary fill-primary/10" />
                    ) : (
                      <div className="h-4 w-4 rounded-full border border-muted-foreground/30" />
                    )}
                  </div>
                  <div className="flex-1">
                    <p className={cn("leading-none mb-1", module.completed && "line-through opacity-70")}>
                      {module.title}
                    </p>
                    <span className="text-xs opacity-70">{module.duration}</span>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </div>

        {/* Main Content Area (Video) */}
        <div className="flex-1 flex flex-col overflow-y-auto bg-muted/10">
          <div className="aspect-video bg-black w-full shrink-0 flex items-center justify-center relative group">
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-8 opacity-0 group-hover:opacity-100 transition-opacity">
              <div className="text-white">
                 <h2 className="text-xl font-bold">Módulo 1: Introdução</h2>
                 <p className="text-sm opacity-80">Próximo: Conceitos Fundamentais</p>
              </div>
            </div>
            <Button size="icon" className="h-16 w-16 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-sm border-2 border-white/20 text-white">
              <Play className="h-8 w-8 ml-1 fill-white" />
            </Button>
          </div>

          <div className="p-6 md:p-8 max-w-4xl mx-auto w-full">
            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="bg-transparent border-b border-border/40 w-full justify-start h-auto p-0 rounded-none gap-6">
                <TabsTrigger value="overview" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-0 py-3 data-[state=active]:shadow-none">Visão Geral</TabsTrigger>
                <TabsTrigger value="resources" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-0 py-3 data-[state=active]:shadow-none">Recursos</TabsTrigger>
                <TabsTrigger value="discussion" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-0 py-3 data-[state=active]:shadow-none">Discussão</TabsTrigger>
              </TabsList>
              
              <TabsContent value="overview" className="mt-6 space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-500">
                <div>
                  <h2 className="text-2xl font-heading font-bold mb-4">Sobre esta aula</h2>
                  <p className="text-muted-foreground leading-relaxed">
                    Neste módulo, exploramos os princípios fundamentais que guiarão sua jornada pelo resto do curso. Quebramos a filosofia central e estabelecemos a estrutura para tudo o que se segue.
                  </p>
                </div>
                
                <div className="p-4 bg-muted/30 rounded-lg border border-border/50">
                  <h3 className="font-semibold mb-2">Principais Aprendizados</h3>
                  <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1">
                    <li>Entendendo o 'Porquê' antes do 'Como'</li>
                    <li>Preparando seu ambiente para o sucesso</li>
                    <li>Os 3 pilares da metodologia</li>
                  </ul>
                </div>
              </TabsContent>
              
              <TabsContent value="resources" className="mt-6">
                <div className="space-y-3">
                  <div className="flex items-center gap-3 p-3 rounded-md border border-border/50 hover:bg-muted/30 transition-colors cursor-pointer">
                    <div className="h-10 w-10 rounded bg-blue-100 text-blue-600 flex items-center justify-center">
                      <FileText className="h-5 w-5" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">Apostila da Aula.pdf</p>
                      <p className="text-xs text-muted-foreground">2.4 MB</p>
                    </div>
                    <Button size="icon" variant="ghost">
                      <Download className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="flex items-center gap-3 p-3 rounded-md border border-border/50 hover:bg-muted/30 transition-colors cursor-pointer">
                    <div className="h-10 w-10 rounded bg-green-100 text-green-600 flex items-center justify-center">
                      <FileText className="h-5 w-5" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">Checklist.xlsx</p>
                      <p className="text-xs text-muted-foreground">1.1 MB</p>
                    </div>
                    <Button size="icon" variant="ghost">
                      <Download className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}
