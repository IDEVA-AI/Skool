import { courses } from "@/lib/data";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Lock, PlayCircle, Search, Filter } from "lucide-react";
import { Link } from "wouter";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";

export default function Courses() {
  const [location, setLocation] = useLocation();

  const handleCardClick = (courseId: number, locked: boolean) => {
    if (locked) {
        // Mock redirect to upsell landing page
        alert("🔒 Este conteúdo é exclusivo. Redirecionando para a página de oferta...");
        // In a real app: window.location.href = course.landingPageUrl;
    } else {
        setLocation(`/courses/${courseId}`);
    }
  };

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-border/40 pb-6">
        <div>
          <h1 className="text-3xl font-heading font-bold text-foreground">Classroom</h1>
          <p className="text-muted-foreground mt-2">Seus treinamentos e materiais exclusivos.</p>
        </div>
        <div className="flex items-center gap-2 w-full md:w-auto">
            <div className="relative w-full md:w-64">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Buscar..." className="pl-9 h-9 bg-muted/50" />
            </div>
            <Button variant="outline" size="icon" className="h-9 w-9 shrink-0">
                <Filter className="h-4 w-4" />
            </Button>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {courses.map((course) => (
          <div 
            key={course.id} 
            onClick={() => handleCardClick(course.id, course.locked)}
            className="cursor-pointer"
          >
              <Card className="h-full flex flex-col overflow-hidden border-border/50 shadow-sm hover:shadow-md hover:border-primary/20 transition-all duration-300 group">
                <div className="relative aspect-video bg-black overflow-hidden flex items-center justify-center">
                  {/* Black minimalist cover */}
                  <div className="absolute inset-0 bg-black" />
                  
                  {/* Text on cover */}
                  <h3 className="relative z-10 font-heading font-black text-2xl text-white text-center px-4 uppercase transform -rotate-2 group-hover:rotate-0 transition-transform duration-300">
                    {course.imageText}
                  </h3>

                  {course.locked && (
                    <div className="absolute inset-0 bg-black/60 backdrop-blur-[1px] z-20 flex flex-col items-center justify-center text-white p-4">
                      <Lock className="h-10 w-10 mb-2 opacity-80" />
                      <span className="font-bold text-sm tracking-widest uppercase opacity-80">Restrito</span>
                    </div>
                  )}

                  {!course.locked && (
                    <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center z-20">
                        <div className="bg-white/10 backdrop-blur-sm rounded-full p-3 transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                            <PlayCircle className="h-8 w-8 text-white" />
                        </div>
                    </div>
                  )}
                </div>
                
                <CardContent className="px-4 pt-4 pb-2 flex-1">
                  <div className="flex items-center gap-2 mb-2">
                     {course.locked ? (
                         <span className="text-[10px] font-bold bg-muted text-muted-foreground px-1.5 py-0.5 rounded uppercase">[BLOQUEADO]</span>
                     ) : (
                         <span className="text-[10px] font-bold bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400 px-1.5 py-0.5 rounded uppercase">LIBERADO</span>
                     )}
                     <h3 className="font-heading font-bold text-sm leading-tight truncate">
                        {course.title}
                     </h3>
                  </div>
                  <p className="text-xs text-muted-foreground line-clamp-3 leading-relaxed">
                    {course.description}
                  </p>
                </CardContent>
                
                <CardFooter className="px-4 py-3 bg-muted/10 border-t border-border/30 mt-auto">
                  <div className="w-full space-y-1.5">
                    <div className="flex justify-between text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
                      <span>Progresso</span>
                      <span>{course.progress}%</span>
                    </div>
                    <Progress value={course.progress} className="h-1.5" />
                  </div>
                </CardFooter>
              </Card>
          </div>
        ))}
      </div>
    </div>
  );
}
