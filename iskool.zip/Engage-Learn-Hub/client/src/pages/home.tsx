import { posts, currentUser } from "@/lib/data";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  ThumbsUp, 
  MessageSquare, 
  Pin, 
  Paperclip, 
  Link as LinkIcon, 
  Youtube, 
  BarChart2, 
  Smile, 
  ChevronDown,
  Lock
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useState } from "react";
import { PostModal } from "@/components/post-modal";

export default function Home() {
  const [isExpanded, setIsExpanded] = useState(false);
  const [selectedPost, setSelectedPost] = useState<any>(null);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Post Modal */}
      <PostModal 
        post={selectedPost} 
        isOpen={!!selectedPost} 
        onClose={() => setSelectedPost(null)} 
      />

      {/* Main Feed */}
      <div className="lg:col-span-2 space-y-6">
        
        {/* New Post Input */}
        <Card className="border-border/50 shadow-sm overflow-hidden transition-all duration-300">
          {!isExpanded ? (
             <CardContent className="p-4 flex items-center gap-4 cursor-text" onClick={() => setIsExpanded(true)}>
               <Avatar className="h-10 w-10">
                 <AvatarImage src={currentUser.avatar} />
                 <AvatarFallback>JC</AvatarFallback>
               </Avatar>
               <div className="flex-1">
                 <input 
                    type="text"
                    placeholder="Escreva algo..." 
                    className="w-full bg-transparent border-none outline-none text-muted-foreground cursor-text"
                    readOnly
                 />
               </div>
             </CardContent>
          ) : (
            <CardContent className="pt-6 pb-4 px-6 space-y-4 animate-in fade-in zoom-in-95 duration-200">
              <div className="flex items-center gap-3 mb-2">
                <Avatar className="h-10 w-10">
                  <AvatarImage src={currentUser.avatar} />
                  <AvatarFallback>JC</AvatarFallback>
                </Avatar>
                <div className="flex items-center gap-1 text-sm">
                  <span className="font-semibold text-foreground">{currentUser.name}</span>
                  <span className="text-muted-foreground">publicando em</span>
                  <span className="font-medium flex items-center gap-1">
                    <span className="bg-muted-foreground/20 rounded-full p-0.5">
                       {/* Icon placeholder if needed */}
                    </span>
                    BACKROOM
                  </span>
                </div>
              </div>

              <div className="space-y-2">
                  <Input 
                      placeholder="Título" 
                      className="text-2xl font-bold border-none shadow-none px-0 focus-visible:ring-0 placeholder:text-muted-foreground/50 h-auto py-0"
                      autoFocus
                  />
                  <Textarea 
                    placeholder="Escreva algo..." 
                    className="min-h-[120px] resize-none border-none shadow-none px-0 focus-visible:ring-0 text-base placeholder:text-muted-foreground/50"
                  />
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-border/10">
                  <div className="flex items-center gap-4 text-muted-foreground">
                      <button className="hover:text-primary transition-colors"><Paperclip className="h-5 w-5" /></button>
                      <button className="hover:text-primary transition-colors"><LinkIcon className="h-5 w-5" /></button>
                      <button className="hover:text-primary transition-colors"><Youtube className="h-5 w-5" /></button>
                      <button className="hover:text-primary transition-colors"><BarChart2 className="h-5 w-5" /></button>
                      <button className="hover:text-primary transition-colors"><Smile className="h-5 w-5" /></button>
                      <button className="hover:text-primary transition-colors font-bold text-xs border border-current rounded px-1 py-0.5">GIF</button>
                  </div>
                  
                  <div className="flex items-center gap-3">
                      <Button variant="ghost" className="text-muted-foreground font-normal hover:bg-transparent hover:text-foreground p-0 h-auto gap-1">
                          Selecionar categoria <ChevronDown className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        className="text-muted-foreground font-semibold hover:bg-transparent hover:text-foreground"
                        onClick={(e) => {
                            e.stopPropagation();
                            setIsExpanded(false);
                        }}
                      >
                        CANCELAR
                      </Button>
                      <Button className="bg-muted text-muted-foreground hover:bg-muted/80 font-semibold px-6" disabled>PUBLICAR</Button>
                  </div>
              </div>
            </CardContent>
          )}
        </Card>

        {/* Posts Feed */}
        <div className="space-y-4">
          {posts.map((post) => (
            <Card 
                key={post.id} 
                className="border-border/50 shadow-sm hover:shadow-md transition-all duration-300 cursor-pointer dark:bg-white/[0.02] dark:hover:bg-white/[0.04]"
                onClick={() => setSelectedPost(post)}
            >
              <CardHeader className="flex flex-row items-start justify-between pb-2 space-y-0">
                <div className="flex gap-3">
                    <Avatar className="h-10 w-10 border-2 border-background">
                        <AvatarImage src={post.avatar} />
                        <AvatarFallback>{post.author[0]}</AvatarFallback>
                    </Avatar>
                    <div>
                        <div className="flex items-center gap-2">
                            <span className="font-bold text-foreground text-sm">{post.author}</span>
                            {/* Role Badge if needed, though image doesn't explicitly emphasize it besides text color */}
                        </div>
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                            {post.pinned && (
                                <span className="bg-blue-600 text-white rounded-full w-4 h-4 flex items-center justify-center text-[10px] font-bold">6</span> 
                            )}
                            <span>{post.timestamp}</span>
                            <span>•</span>
                            <span className="uppercase font-medium text-xs tracking-wide text-muted-foreground/80">[{post.role}]</span>
                        </div>
                    </div>
                </div>

                {post.pinned && (
                  <div className="flex items-center gap-1 text-xs font-semibold text-foreground">
                    <Pin className="h-3.5 w-3.5 fill-foreground" />
                    Fixado
                  </div>
                )}
              </CardHeader>
              
              <CardContent className="pb-4 block flow-root">
                <div className="space-y-3">
                  <div className="flex items-start gap-2">
                      {post.pinned && <span className="mt-1.5 h-2 w-2 rounded-full bg-blue-500 shrink-0" />}
                      {post.pinned && <span className="mt-1 text-lg">🚨</span>}
                      <h3 className="text-xl font-bold leading-tight">{post.title}</h3>
                  </div>
                  <p className="text-sm leading-relaxed text-foreground/90 whitespace-pre-line pl-0">
                    {post.content}
                  </p>
                </div>
              </CardContent>
              
              <CardFooter className="pt-2 pb-4 flex items-center justify-between">
                <div className="flex gap-4">
                  <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-primary gap-2 h-8 px-2">
                    <ThumbsUp className="h-5 w-5" />
                    <span className="text-sm font-medium">{post.likes}</span>
                  </Button>
                  <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-primary gap-2 h-8 px-2">
                    <MessageSquare className="h-5 w-5" />
                    <span className="text-sm font-medium">{post.comments}</span>
                  </Button>
                </div>

                {post.likedBy && (
                    <div className="flex items-center gap-3">
                        <div className="flex -space-x-2">
                            {post.likedBy.map((url, i) => (
                                <Avatar key={i} className="h-6 w-6 border-2 border-background">
                                    <AvatarImage src={url} />
                                    <AvatarFallback>U</AvatarFallback>
                                </Avatar>
                            ))}
                        </div>
                        <span className="text-xs font-medium text-blue-600 hover:underline cursor-pointer">
                            {post.lastComment}
                        </span>
                    </div>
                )}
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>

      {/* Sidebar Widgets */}
      <div className="space-y-6">
        <Card className="bg-primary/5 border-primary/10 shadow-none">
          <CardHeader className="pb-3">
            <h3 className="font-heading font-semibold text-lg text-primary">Anúncios</h3>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <span className="text-xs font-medium text-muted-foreground block">Amanhã, 14:00</span>
              <p className="text-sm font-medium">Q&A ao vivo com Sarah: "Minimalismo nos Negócios"</p>
            </div>
            <div className="h-px bg-primary/10" />
            <div className="space-y-2">
              <span className="text-xs font-medium text-muted-foreground block">Novo Módulo Adicionado</span>
              <p className="text-sm font-medium">Pensamento Estratégico Avançado: Módulo 4 já está disponível.</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/50 shadow-sm">
          <CardHeader className="pb-3">
            <h3 className="font-heading font-semibold text-lg">Seu Progresso</h3>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="font-medium">Fundamentos do Minimalismo</span>
                  <span className="text-muted-foreground">75%</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-secondary w-[75%]" />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="font-medium">Ecossistema Digital</span>
                  <span className="text-muted-foreground">30%</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-accent w-[30%]" />
                </div>
              </div>
            </div>
            <Button variant="outline" className="w-full mt-4 text-xs" asChild>
              <a href="/courses">Continuar Aprendendo</a>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
