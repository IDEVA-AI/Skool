import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Bell, ChevronDown } from "lucide-react";
import { notifications } from "@/lib/data";

export function NotificationDropdown() {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative text-muted-foreground hover:text-foreground">
            <Bell className="h-5 w-5" />
            <span className="absolute -top-0.5 -right-1 h-auto min-w-[16px] px-1 bg-red-500 text-[10px] font-bold text-white flex items-center justify-center rounded-full border-2 border-background">99+</span>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[380px] p-0" align="end">
        <div className="p-4 pb-2 flex items-center justify-between border-b border-border/40 mb-1">
            <h3 className="font-heading font-bold text-lg">Notificações</h3>
            <div className="flex items-center gap-4 text-xs font-medium text-muted-foreground">
                <button className="hover:text-primary transition-colors">Marcar tudo como lido</button>
                <button className="flex items-center gap-1 hover:text-primary transition-colors">
                    Todos os grupos <ChevronDown className="h-3 w-3" />
                </button>
            </div>
        </div>

        <ScrollArea className="h-[400px]">
            <div className="flex flex-col">
                {notifications.map((notif) => (
                    <button 
                        key={notif.id}
                        className="flex items-start gap-3 p-4 hover:bg-muted/50 transition-colors text-left border-b border-border/40 last:border-none"
                    >
                        <div className="relative shrink-0">
                            <Avatar className="h-10 w-10 border border-border/50">
                                <AvatarImage src={notif.avatar} />
                                <AvatarFallback>{notif.user[0]}</AvatarFallback>
                            </Avatar>
                            {/* Icon overlay for post type/context if needed, though image shows emoji in text */}
                        </div>
                        
                        <div className="flex-1 min-w-0">
                            <div className="flex items-baseline justify-between gap-2 mb-0.5">
                                <div className="text-sm font-bold truncate">
                                    {notif.user} 
                                    {notif.icon && <span className="mx-1">{notif.icon}</span>}
                                    <span className="font-normal text-muted-foreground ml-1">{notif.context}</span>
                                    <span className="font-normal text-muted-foreground ml-1">{notif.action}</span>
                                </div>
                                <span className="text-xs text-muted-foreground shrink-0 whitespace-nowrap">{notif.timestamp}</span>
                            </div>
                            <p className="text-sm text-foreground/90 leading-snug line-clamp-2">
                                {notif.isImportant && <span className="mr-1">🚨</span>}
                                {notif.isImportant && <span className="mr-1"></span>}
                                {notif.content}
                            </p>
                        </div>
                        {notif.unread && (
                            <div className="h-2.5 w-2.5 bg-blue-500 rounded-full mt-2 shrink-0" />
                        )}
                    </button>
                ))}
            </div>
        </ScrollArea>

        <div className="p-2 border-t border-border/40 text-center">
            <Button variant="ghost" size="sm" className="w-full text-xs text-muted-foreground h-8">
                Ver todas as notificações
            </Button>
        </div>
      </PopoverContent>
    </Popover>
  );
}
