import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { MessageSquare, Search, ChevronDown } from "lucide-react";
import { chats } from "@/lib/data";

export function ChatDropdown() {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative text-muted-foreground hover:text-foreground">
            <MessageSquare className="h-5 w-5" />
            <span className="absolute -top-0.5 -right-0.5 h-4 w-4 bg-red-500 text-[10px] font-bold text-white flex items-center justify-center rounded-full border-2 border-background">3</span>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[380px] p-0" align="end">
        <div className="p-4 pb-2">
            <div className="flex items-center justify-between mb-4">
                <h3 className="font-heading font-bold text-lg">Conversas</h3>
                <div className="flex items-center gap-4 text-xs font-medium text-muted-foreground">
                    <button className="hover:text-primary transition-colors">Marcar tudo como lido</button>
                    <button className="flex items-center gap-1 hover:text-primary transition-colors">
                        Tudo <ChevronDown className="h-3 w-3" />
                    </button>
                </div>
            </div>
            
            <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input 
                    placeholder="Pesquisar usuários" 
                    className="pl-9 bg-muted/50 border-none h-9 text-sm"
                />
            </div>
        </div>

        <ScrollArea className="h-[400px]">
            <div className="flex flex-col">
                {chats.map((chat) => (
                    <button 
                        key={chat.id}
                        className="flex items-start gap-3 p-4 hover:bg-muted/50 transition-colors text-left border-b border-border/40 last:border-none"
                    >
                        <Avatar className="h-10 w-10 border border-border/50 shrink-0">
                            <AvatarImage src={chat.avatar} />
                            <AvatarFallback>{chat.user[0]}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0 overflow-hidden">
                            <div className="flex items-center justify-between mb-0.5">
                                <span className="font-bold text-sm truncate flex items-center gap-1.5">
                                    {chat.user}
                                    {chat.count && <span className="text-muted-foreground font-normal">({chat.count})</span>}
                                </span>
                                <span className="text-xs text-muted-foreground shrink-0">{chat.timestamp}</span>
                            </div>
                            <p className="text-sm text-muted-foreground truncate leading-snug">
                                {chat.message}
                            </p>
                        </div>
                        {chat.unread && (
                            <div className="h-2.5 w-2.5 bg-blue-500 rounded-full mt-2 shrink-0" />
                        )}
                    </button>
                ))}
            </div>
        </ScrollArea>

        <div className="p-2 border-t border-border/40 text-center">
            <Button variant="ghost" size="sm" className="w-full text-xs text-muted-foreground h-8">
                Ver todas as mensagens
            </Button>
        </div>
      </PopoverContent>
    </Popover>
  );
}
