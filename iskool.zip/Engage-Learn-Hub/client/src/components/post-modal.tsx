import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress } from "@/components/ui/progress";
import { ThumbsUp, MessageSquare, Lock, Pin, MoreHorizontal, ArrowDown, Send } from "lucide-react";
import { VisuallyHidden } from "@radix-ui/react-visually-hidden";
import { currentUser } from "@/lib/data";

interface Comment {
  id: number;
  author: string;
  avatar: string;
  role?: string;
  content: string;
  timestamp: string;
  likes: number;
  replies?: Comment[];
}

interface Post {
  id: number;
  author: string;
  role: string;
  avatar: string;
  title: string;
  content: string;
  timestamp: string;
  likes: number;
  comments: number;
  pinned: boolean;
  attachment?: {
    title: string;
    description: string;
    image: string;
    progress: number;
    locked: boolean;
  };
  commentsList?: Comment[];
}

interface PostModalProps {
  post: Post | null;
  isOpen: boolean;
  onClose: () => void;
}

export function PostModal({ post, isOpen, onClose }: PostModalProps) {
  if (!post) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl h-[85vh] p-0 gap-0 overflow-hidden flex flex-col bg-background/95 backdrop-blur-xl border-border/40 shadow-2xl">
        <VisuallyHidden>
            <DialogTitle>{post.title}</DialogTitle>
        </VisuallyHidden>

        <ScrollArea className="flex-1">
          <div className="p-6 md:p-8 space-y-6">
            {/* Header */}
            <div className="flex items-start justify-between">
              <div className="flex gap-3">
                <Avatar className="h-10 w-10 border-2 border-background shadow-sm">
                  <AvatarImage src={post.avatar} />
                  <AvatarFallback>{post.author[0]}</AvatarFallback>
                </Avatar>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-foreground text-sm">{post.author}</span>
                  </div>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <span>{post.timestamp}</span>
                    <span>•</span>
                    <span className="uppercase font-medium text-xs tracking-wide text-muted-foreground/80">
                      [{post.role}]
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                 <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground">
                    <MoreHorizontal className="h-4 w-4" />
                 </Button>
              </div>
            </div>

            {/* Content */}
            <div className="space-y-4">
              <div className="flex items-start gap-2">
                {post.pinned && <span className="mt-1.5 h-2 w-2 rounded-full bg-blue-500 shrink-0" />}
                {post.pinned && <span className="mt-1 text-lg">🚨</span>}
                <h2 className="text-xl font-bold leading-tight">{post.title}</h2>
              </div>
              
              <div className="prose prose-sm dark:prose-invert max-w-none text-foreground/90 whitespace-pre-line leading-relaxed">
                {post.content}
              </div>
            </div>

            {/* Interaction Bar */}
            <div className="flex items-center gap-4 pt-4 border-b border-border/40 pb-4">
               <Button variant="outline" size="sm" className="gap-2 h-8 rounded-md px-3 font-medium text-xs border-border/60">
                 <ThumbsUp className="h-3.5 w-3.5" />
                 Curtir
                 <span className="bg-muted px-1.5 py-0.5 rounded text-[10px] ml-1">{post.likes}</span>
               </Button>
               <div className="flex items-center gap-2 text-xs text-muted-foreground ml-2">
                  <MessageSquare className="h-3.5 w-3.5" />
                  {post.comments} comentários
               </div>
            </div>

            {/* Comments Section */}
            <div className="space-y-6 pt-2">
                {post.commentsList?.map((comment) => (
                    <div key={comment.id} className="space-y-4">
                        {/* Parent Comment */}
                        <div className="flex gap-3">
                             <Avatar className="h-8 w-8 border border-border/50">
                                <AvatarImage src={comment.avatar} />
                                <AvatarFallback>{comment.author[0]}</AvatarFallback>
                            </Avatar>
                            <div className="flex-1 space-y-1">
                                <div className="flex items-baseline justify-between">
                                    <div className="flex items-center gap-2">
                                        <span className="font-bold text-sm text-foreground">{comment.author}</span>
                                        <span className="text-xs text-muted-foreground">{comment.timestamp}</span>
                                    </div>
                                </div>
                                <p className="text-sm text-foreground/90 whitespace-pre-line leading-relaxed">{comment.content}</p>
                                <div className="flex items-center gap-4 pt-1">
                                    <button className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground hover:text-foreground transition-colors">
                                        <ThumbsUp className="h-3 w-3" />
                                        {comment.likes > 0 && <span>{comment.likes}</span>}
                                    </button>
                                    <button className="text-xs font-medium text-muted-foreground hover:text-foreground transition-colors">
                                        Responder
                                    </button>
                                </div>
                            </div>
                        </div>

                        {/* Replies */}
                        {comment.replies && (
                            <div className="pl-11 space-y-4">
                                {comment.replies.map((reply) => (
                                     <div key={reply.id} className="flex gap-3 relative">
                                        {/* Thread line */}
                                        <div className="absolute -left-5 top-0 bottom-0 w-px bg-border/40" />
                                        <div className="absolute -left-5 top-4 w-3 h-px bg-border/40" />
                                        
                                        <Avatar className="h-8 w-8 border border-border/50">
                                            <AvatarImage src={reply.avatar} />
                                            <AvatarFallback>{reply.author[0]}</AvatarFallback>
                                        </Avatar>
                                        <div className="flex-1 space-y-1 bg-muted/30 p-3 rounded-lg border border-border/20">
                                            <div className="flex items-baseline justify-between">
                                                <div className="flex items-center gap-2">
                                                    <span className="font-bold text-sm text-foreground">{reply.author}</span>
                                                    <span className="text-xs text-muted-foreground">{reply.timestamp}</span>
                                                </div>
                                            </div>
                                            <div className="text-sm text-foreground/90 whitespace-pre-line leading-relaxed prose prose-sm dark:prose-invert max-w-none">
                                                {/* Highlight mentions roughly */}
                                                {reply.content.split(/(@[\w\s]+)/g).map((part, i) => 
                                                    part.startsWith('@') ? <span key={i} className="text-primary font-medium">{part}</span> : part
                                                )}
                                            </div>
                                             <div className="flex items-center gap-4 pt-2">
                                                <button className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground hover:text-foreground transition-colors">
                                                    <ThumbsUp className="h-3 w-3" />
                                                    {reply.likes > 0 && <span>{reply.likes}</span>}
                                                </button>
                                                <button className="text-xs font-medium text-muted-foreground hover:text-foreground transition-colors">
                                                    Responder
                                                </button>
                                            </div>
                                        </div>
                                     </div>
                                ))}
                            </div>
                        )}
                    </div>
                ))}
            </div>
          </div>
        </ScrollArea>
        
        {/* Floating Action Button (Jump to latest) */}
        <div className="absolute bottom-24 left-1/2 -translate-x-1/2 z-20">
             <Button variant="secondary" size="sm" className="shadow-lg rounded-full gap-2 text-xs font-medium h-8 bg-background border border-border text-foreground hover:bg-muted">
                <ArrowDown className="h-3 w-3" />
                Ir para o último comentário
             </Button>
        </div>

        {/* Comment Input Footer */}
        <div className="p-4 bg-background border-t border-border z-10">
          <div className="flex gap-3">
            <Avatar className="h-9 w-9 border border-border/50">
              <AvatarImage src={currentUser.avatar} />
              <AvatarFallback>JC</AvatarFallback>
            </Avatar>
            <div className="flex-1 relative">
              <textarea
                className="w-full bg-muted/50 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary/20 resize-none min-h-[44px] max-h-32 text-foreground placeholder:text-muted-foreground"
                placeholder="Escreva um comentário..."
                rows={1}
              />
              <div className="absolute right-2 bottom-1.5">
                <Button size="icon" variant="ghost" className="h-8 w-8 text-muted-foreground hover:text-primary">
                    <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
